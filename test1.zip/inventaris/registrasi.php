<?php
require_once 'includes/init.php';

if (sudah_login()) {
    redirect('dashboard.php');
}

$errors = [];
$nilai = ['nama' => '', 'username' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!cek_csrf()) {
        $errors['umum'] = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } else {
        $nilai['nama'] = ambil_input('nama');
        $nilai['username'] = strtolower(ambil_input('username'));
        $password = ambil_input('password', false);
        $konfirmasi = ambil_input('konfirmasi', false);

        $errors = validasi_registrasi($nilai['nama'], $nilai['username'], $password, $konfirmasi);

        if (!$errors && cari_user($koneksi, $nilai['username'])) {
            $errors['username'] = 'Username sudah dipakai.';
        }

        if (!$errors) {
            try {
                tambah_user($koneksi, $nilai['nama'], $nilai['username'], $password);
                set_flash('success', 'Registrasi berhasil. Silakan login.');
                redirect('login.php');
            } catch (mysqli_sql_exception $ex) {
                if ($ex->getCode() === 1062) {
                    $errors['username'] = 'Username sudah dipakai.';
                } else {
                    $errors['umum'] = 'Registrasi gagal. Silakan coba lagi.';
                }
            }
        }
    }
}

$judul = 'Registrasi';
require 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-12 col-md-8 col-lg-5">
        <div class="card">
            <div class="card-body p-4">
                <h1 class="h4 mb-3">Buat akun</h1>

                <?php if (isset($errors['umum'])): ?>
                    <div class="alert alert-danger"><?= e($errors['umum']) ?></div>
                <?php endif; ?>

                <form method="post" action="registrasi.php" novalidate>
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama lengkap</label>
                        <input type="text" id="nama" name="nama" maxlength="100"
                               class="form-control<?= kelas_invalid($errors, 'nama') ?>" value="<?= e($nilai['nama']) ?>">
                        <div class="invalid-feedback"><?= e($errors['nama'] ?? '') ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" id="username" name="username" maxlength="30" autocomplete="username"
                               class="form-control<?= kelas_invalid($errors, 'username') ?>" value="<?= e($nilai['username']) ?>">
                        <div class="invalid-feedback"><?= e($errors['username'] ?? '') ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" name="password" autocomplete="new-password"
                               class="form-control<?= kelas_invalid($errors, 'password') ?>">
                        <div class="invalid-feedback"><?= e($errors['password'] ?? '') ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="konfirmasi" class="form-label">Ulangi password</label>
                        <input type="password" id="konfirmasi" name="konfirmasi" autocomplete="new-password"
                               class="form-control<?= kelas_invalid($errors, 'konfirmasi') ?>">
                        <div class="invalid-feedback"><?= e($errors['konfirmasi'] ?? '') ?></div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Daftar</button>
                </form>

                <p class="mt-3 mb-0 text-center">Sudah punya akun? <a href="login.php">Login</a></p>
            </div>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
