<?php
require_once 'includes/init.php';

if (sudah_login()) {
    redirect('dashboard.php');
}

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!cek_csrf()) {
        $error = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } else {
        $username = strtolower(ambil_input('username'));
        $password = ambil_input('password', false);

        if ($username === '' || $password === '') {
            $error = 'Username dan password wajib diisi.';
        } else {
            $user = cari_user($koneksi, $username);

            if ($user && password_verify($password, $user['password'])) {
                session_regenerate_id(true); // cegah session fixation
                $_SESSION['user_id'] = (int) $user['id'];
                $_SESSION['user_nama'] = $user['nama'];
                redirect('dashboard.php');
            }
            $error = 'Username atau password salah.';
        }
    }
}

$judul = 'Login';
require 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-12 col-md-8 col-lg-5">
        <div class="card">
            <div class="card-body p-4">
                <h1 class="h4 mb-3">Login</h1>

                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger"><?= e($error) ?></div>
                <?php endif; ?>

                <form method="post" action="login.php" novalidate>
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" id="username" name="username" class="form-control"
                               autocomplete="username" value="<?= e($username) ?>">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" name="password" class="form-control"
                               autocomplete="current-password">
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Masuk</button>
                </form>

                <p class="mt-3 mb-0 text-center">Belum punya akun? <a href="registrasi.php">Registrasi</a></p>
            </div>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
