<?php
require_once 'includes/init.php';

wajib_post();

if (!cek_csrf()) {
    redirect('dashboard.php');
}

// Hapus semua data session, lalu mulai session baru untuk pesan
$_SESSION = [];
session_destroy();
mulai_session();
session_regenerate_id(true);

set_flash('success', 'Anda sudah logout.');
redirect('login.php');
