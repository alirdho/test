<?php
require_once 'includes/init.php';
wajib_login();
wajib_post();

if (!cek_csrf()) {
    set_flash('danger', 'Sesi tidak valid. Silakan coba lagi.');
    redirect('barang.php');
}

$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

if ($id === false) {
    set_flash('danger', 'ID barang tidak valid.');
} elseif (hapus_barang($koneksi, $id)) {
    set_flash('success', 'Barang berhasil dihapus.');
} else {
    set_flash('danger', 'Data barang tidak ditemukan.');
}

redirect('barang.php');
