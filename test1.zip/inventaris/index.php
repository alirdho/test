<?php
require_once 'includes/init.php';

redirect(sudah_login() ? 'dashboard.php' : 'login.php');
