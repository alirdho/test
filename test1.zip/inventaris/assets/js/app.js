// Konfirmasi sebelum form dikirim (dipakai untuk hapus data).
// Cara pakai: <form data-konfirmasi="Pesan konfirmasi">
document.querySelectorAll('form[data-konfirmasi]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
        if (!confirm(form.dataset.konfirmasi)) {
            event.preventDefault();
        }
    });
});
