<?php
require_once 'includes/init.php';
wajib_login();

if (!is_file(__DIR__ . '/lib/fpdf/fpdf.php')) {
    set_flash('danger', 'Library FPDF belum dipasang. Letakkan fpdf.php di folder lib/fpdf/.');
    redirect('laporan.php');
}

require_once 'fungsi/pdf.php';

$daftar = ambil_semua_barang($koneksi, '', false);
$total = hitung_total($daftar);

buat_laporan_pdf($daftar, $total, $_SESSION['user_nama']);
