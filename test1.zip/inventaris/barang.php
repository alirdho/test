<?php
require_once 'includes/init.php';
wajib_login();

$cari = isset($_GET['q']) && is_string($_GET['q']) ? trim($_GET['q']) : '';
$daftar = ambil_semua_barang($koneksi, $cari);

$judul = 'Data Barang';
require 'includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h4 mb-0">Data Barang</h1>
    <a href="barang_form.php" class="btn btn-primary">Tambah barang</a>
</div>

<form method="get" action="barang.php" class="row g-2 mb-3">
    <div class="col-12 col-sm">
        <label for="q" class="visually-hidden">Cari barang</label>
        <input type="search" id="q" name="q" class="form-control" placeholder="Cari kode, nama, atau kategori"
               value="<?= e($cari) ?>">
    </div>
    <div class="col-12 col-sm-auto d-flex gap-2">
        <button type="submit" class="btn btn-outline-primary">Cari</button>
        <?php if ($cari !== ''): ?>
            <a href="barang.php" class="btn btn-outline-secondary">Reset</a>
        <?php endif; ?>
    </div>
</form>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Kategori</th>
                    <th class="kolom-angka">Harga</th>
                    <th class="kolom-angka">Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$daftar): ?>
                    <tr>
                        <td colspan="7" class="text-center text-secondary py-4">
                            <?= $cari !== '' ? 'Tidak ada barang yang cocok dengan pencarian.' : 'Belum ada data barang.' ?>
                        </td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($daftar as $i => $b): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= e($b['kode']) ?></td>
                        <td><?= e($b['nama']) ?></td>
                        <td><?= e($b['kategori']) ?></td>
                        <td class="kolom-angka"><?= e(rupiah($b['harga'])) ?></td>
                        <td class="kolom-angka"><?= e($b['stok']) ?></td>
                        <td class="text-nowrap">
                            <a href="barang_form.php?id=<?= (int) $b['id'] ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                            <form method="post" action="barang_hapus.php" class="d-inline"
                                  data-konfirmasi="Hapus barang <?= e($b['nama']) ?>? Data tidak bisa dikembalikan.">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $b['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
