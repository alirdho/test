<?php
require_once 'includes/init.php';
wajib_login();

$daftar = ambil_semua_barang($koneksi, '', false);
$total = hitung_total($daftar);

$judul = 'Laporan';
require 'includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h4 mb-0">Laporan Data Barang</h1>
    <a href="laporan_pdf.php" target="_blank" class="btn btn-primary">Cetak PDF</a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Kategori</th>
                    <th class="kolom-angka">Harga</th>
                    <th class="kolom-angka">Stok</th>
                    <th class="kolom-angka">Nilai</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$daftar): ?>
                    <tr><td colspan="7" class="text-center text-secondary py-4">Belum ada data barang.</td></tr>
                <?php endif; ?>

                <?php foreach ($daftar as $i => $b): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td><?= e($b['kode']) ?></td>
                        <td><?= e($b['nama']) ?></td>
                        <td><?= e($b['kategori']) ?></td>
                        <td class="kolom-angka"><?= e(rupiah($b['harga'])) ?></td>
                        <td class="kolom-angka"><?= e($b['stok']) ?></td>
                        <td class="kolom-angka"><?= e(rupiah((int) $b['harga'] * (int) $b['stok'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="fw-semibold">
                    <td colspan="5" class="text-end">Total (<?= (int) $total['jumlah'] ?> barang)</td>
                    <td class="kolom-angka"><?= e($total['stok']) ?></td>
                    <td class="kolom-angka"><?= e(rupiah($total['nilai'])) ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
