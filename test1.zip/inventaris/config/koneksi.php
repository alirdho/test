<?php
// Pengaturan bawaan XAMPP. Ubah jika MySQL Anda berbeda.
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_nama = 'db_inventaris';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $koneksi = new mysqli($db_host, $db_user, $db_pass, $db_nama);
    $koneksi->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    exit('Koneksi database gagal. Pastikan MySQL di XAMPP sudah aktif dan database.sql sudah diimport.');
}
