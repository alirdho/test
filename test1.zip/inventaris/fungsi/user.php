<?php
function cari_user(mysqli $koneksi, string $username): ?array
{
    $stmt = $koneksi->prepare('SELECT id, nama, username, password FROM users WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $user ?: null;
}

function tambah_user(mysqli $koneksi, string $nama, string $username, string $password): void
{
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $koneksi->prepare('INSERT INTO users (nama, username, password) VALUES (?, ?, ?)');
    $stmt->bind_param('sss', $nama, $username, $hash);
    $stmt->execute();
    $stmt->close();
}
