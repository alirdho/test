<?php
// $terbaru = true  -> urut data terbaru; false -> urut kode (untuk laporan)
function ambil_semua_barang(mysqli $koneksi, string $cari = '', bool $terbaru = true): array
{
    $urut = $terbaru ? 'id DESC' : 'kode ASC';

    if ($cari !== '') {
        $like = '%' . addcslashes($cari, '%_\\') . '%';
        $stmt = $koneksi->prepare(
            "SELECT * FROM barang WHERE kode LIKE ? OR nama LIKE ? OR kategori LIKE ? ORDER BY $urut"
        );
        $stmt->bind_param('sss', $like, $like, $like);
    } else {
        $stmt = $koneksi->prepare("SELECT * FROM barang ORDER BY $urut");
    }

    $stmt->execute();
    $data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $data;
}

function ambil_barang(mysqli $koneksi, int $id): ?array
{
    $stmt = $koneksi->prepare('SELECT * FROM barang WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $barang = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $barang ?: null;
}

// $kecuali_id dipakai saat edit agar barang itu sendiri tidak dianggap duplikat
function kode_sudah_ada(mysqli $koneksi, string $kode, int $kecuali_id = 0): bool
{
    $stmt = $koneksi->prepare('SELECT id FROM barang WHERE kode = ? AND id <> ?');
    $stmt->bind_param('si', $kode, $kecuali_id);
    $stmt->execute();
    $ada = $stmt->get_result()->num_rows > 0;
    $stmt->close();
    return $ada;
}

function tambah_barang(mysqli $koneksi, array $d): void
{
    $harga = (int) $d['harga'];
    $stok = (int) $d['stok'];
    $stmt = $koneksi->prepare('INSERT INTO barang (kode, nama, kategori, harga, stok) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('sssii', $d['kode'], $d['nama'], $d['kategori'], $harga, $stok);
    $stmt->execute();
    $stmt->close();
}

function ubah_barang(mysqli $koneksi, int $id, array $d): void
{
    $harga = (int) $d['harga'];
    $stok = (int) $d['stok'];
    $stmt = $koneksi->prepare('UPDATE barang SET kode = ?, nama = ?, kategori = ?, harga = ?, stok = ? WHERE id = ?');
    $stmt->bind_param('sssiii', $d['kode'], $d['nama'], $d['kategori'], $harga, $stok, $id);
    $stmt->execute();
    $stmt->close();
}

function hapus_barang(mysqli $koneksi, int $id): bool
{
    $stmt = $koneksi->prepare('DELETE FROM barang WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $terhapus = $stmt->affected_rows > 0;
    $stmt->close();
    return $terhapus;
}

// Hitung jumlah barang, total stok, dan total nilai (harga x stok)
function hitung_total(array $daftar): array
{
    $total = ['jumlah' => count($daftar), 'stok' => 0, 'nilai' => 0];

    foreach ($daftar as $barang) {
        $total['stok'] += (int) $barang['stok'];
        $total['nilai'] += (int) $barang['harga'] * (int) $barang['stok'];
    }

    return $total;
}
