<?php
function mulai_session(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
        session_start();
    }
}

// Escape output agar aman dari XSS
function e($teks): string
{
    return htmlspecialchars((string) $teks, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function rupiah($angka): string
{
    return 'Rp ' . number_format((int) $angka, 0, ',', '.');
}

// ---- Login & session ----
function sudah_login(): bool
{
    return isset($_SESSION['user_id']);
}

function wajib_login(): void
{
    if (!sudah_login()) {
        set_flash('secondary', 'Silakan login terlebih dahulu.');
        redirect('login.php');
    }
}

function wajib_post(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        redirect('dashboard.php');
    }
}

// ---- CSRF ----
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function cek_csrf(): bool
{
    $kiriman = $_POST['csrf'] ?? '';
    return is_string($kiriman) && hash_equals(csrf_token(), $kiriman);
}

// ---- Pesan sekali tampil (flash) ----
function set_flash(string $tipe, string $pesan): void
{
    $_SESSION['flash'] = ['tipe' => $tipe, 'pesan' => $pesan];
}

function ambil_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

// ---- Lain-lain ----
// Ambil ?id= dari URL. Hasilnya null jika tidak valid.
function ambil_id(): ?int
{
    $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    return $id === false ? null : $id;
}

function menu_aktif(array $file): string
{
    return in_array(basename($_SERVER['PHP_SELF']), $file, true) ? ' active' : '';
}

function kelas_invalid(array $errors, string $field): string
{
    return isset($errors[$field]) ? ' is-invalid' : '';
}
