<?php
function ambil_input(string $nama, bool $trim = true): string
{
    $nilai = $_POST[$nama] ?? '';
    if (!is_string($nilai)) {
        return '';
    }
    return $trim ? trim($nilai) : $nilai;
}

function ambil_data_barang(): array
{
    return [
        'kode'     => strtoupper(ambil_input('kode')),
        'nama'     => ambil_input('nama'),
        'kategori' => ambil_input('kategori'),
        'harga'    => ambil_input('harga'),
        'stok'     => ambil_input('stok'),
    ];
}

// Mengembalikan array pesan error (kosong = valid)
function validasi_barang(array $d): array
{
    $err = [];

    if ($d['kode'] === '') {
        $err['kode'] = 'Kode wajib diisi.';
    } elseif (!preg_match('/^[A-Z0-9-]{1,20}$/', $d['kode'])) {
        $err['kode'] = 'Kode hanya boleh huruf, angka, dan tanda minus (maksimal 20 karakter).';
    }

    if ($d['nama'] === '') {
        $err['nama'] = 'Nama wajib diisi.';
    } elseif (mb_strlen($d['nama']) > 100) {
        $err['nama'] = 'Nama maksimal 100 karakter.';
    }

    if ($d['kategori'] === '') {
        $err['kategori'] = 'Kategori wajib diisi.';
    } elseif (mb_strlen($d['kategori']) > 50) {
        $err['kategori'] = 'Kategori maksimal 50 karakter.';
    }

    if ($d['harga'] === '') {
        $err['harga'] = 'Harga wajib diisi.';
    } elseif (!ctype_digit($d['harga']) || strlen($d['harga']) > 9) {
        $err['harga'] = 'Harga harus berupa angka bulat 0 sampai 999999999.';
    }

    if ($d['stok'] === '') {
        $err['stok'] = 'Stok wajib diisi.';
    } elseif (!ctype_digit($d['stok']) || strlen($d['stok']) > 7) {
        $err['stok'] = 'Stok harus berupa angka bulat 0 sampai 9999999.';
    }

    return $err;
}

function validasi_registrasi(string $nama, string $username, string $password, string $konfirmasi): array
{
    $err = [];

    if ($nama === '') {
        $err['nama'] = 'Nama wajib diisi.';
    } elseif (mb_strlen($nama) > 100) {
        $err['nama'] = 'Nama maksimal 100 karakter.';
    }

    if (!preg_match('/^[a-z0-9_]{4,30}$/', $username)) {
        $err['username'] = 'Username 4-30 karakter: huruf kecil, angka, dan garis bawah.';
    }

    if (strlen($password) < 8) {
        $err['password'] = 'Password minimal 8 karakter.';
    } elseif (strlen($password) > 72) {
        $err['password'] = 'Password maksimal 72 karakter.';
    }

    if ($konfirmasi !== $password) {
        $err['konfirmasi'] = 'Konfirmasi password tidak sama.';
    }

    return $err;
}
