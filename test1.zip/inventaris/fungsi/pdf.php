<?php
require_once __DIR__ . '/../lib/fpdf/fpdf.php';

// FPDF memakai encoding Windows-1252, jadi teks UTF-8 perlu dikonversi
function teks_pdf(string $teks): string
{
    return mb_convert_encoding($teks, 'Windows-1252', 'UTF-8');
}

function pdf_header_tabel(FPDF $pdf, array $kolom): void
{
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetFillColor(29, 78, 137);
    $pdf->SetTextColor(255, 255, 255);
    foreach ($kolom as $judul => $lebar) {
        $pdf->Cell($lebar, 8, teks_pdf($judul), 1, 0, 'C', true);
    }
    $pdf->Ln();
    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont('Arial', '', 9);
}

function buat_laporan_pdf(array $daftar, array $total, string $pencetak): void
{
    $kolom = ['No' => 10, 'Kode' => 22, 'Nama Barang' => 50, 'Kategori' => 32, 'Harga' => 26, 'Stok' => 14, 'Nilai' => 36];

    $pdf = new FPDF('P', 'mm', 'A4');
    $pdf->SetTitle('Laporan Data Barang');
    $pdf->AddPage();

    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 8, 'Laporan Data Barang', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 9);
    $pdf->Cell(0, 5, 'Dicetak oleh ' . teks_pdf($pencetak) . ' pada ' . date('d-m-Y H:i'), 0, 1, 'C');
    $pdf->Ln(5);

    pdf_header_tabel($pdf, $kolom);

    $no = 1;
    foreach ($daftar as $b) {
        if ($pdf->GetY() > 270) {
            $pdf->AddPage();
            pdf_header_tabel($pdf, $kolom);
        }
        $nilai = (int) $b['harga'] * (int) $b['stok'];

        $pdf->Cell($kolom['No'], 7, $no++, 1, 0, 'C');
        $pdf->Cell($kolom['Kode'], 7, teks_pdf($b['kode']), 1);
        $pdf->Cell($kolom['Nama Barang'], 7, teks_pdf(mb_strimwidth($b['nama'], 0, 30, '...')), 1);
        $pdf->Cell($kolom['Kategori'], 7, teks_pdf(mb_strimwidth($b['kategori'], 0, 18, '...')), 1);
        $pdf->Cell($kolom['Harga'], 7, rupiah($b['harga']), 1, 0, 'R');
        $pdf->Cell($kolom['Stok'], 7, $b['stok'], 1, 0, 'R');
        $pdf->Cell($kolom['Nilai'], 7, rupiah($nilai), 1, 1, 'R');
    }

    if (count($daftar) === 0) {
        $pdf->Cell(array_sum($kolom), 8, 'Belum ada data barang.', 1, 1, 'C');
    }

    // Baris total
    $lebar_label = $kolom['No'] + $kolom['Kode'] + $kolom['Nama Barang'] + $kolom['Kategori'] + $kolom['Harga'];
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->Cell($lebar_label, 8, 'Total (' . $total['jumlah'] . ' barang)', 1, 0, 'R');
    $pdf->Cell($kolom['Stok'], 8, $total['stok'], 1, 0, 'R');
    $pdf->Cell($kolom['Nilai'], 8, rupiah($total['nilai']), 1, 1, 'R');

    $pdf->Output('I', 'laporan-barang.pdf');
}
