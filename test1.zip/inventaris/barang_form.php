<?php
require_once 'includes/init.php';
wajib_login();

// Halaman ini dipakai untuk tambah (tanpa ?id) dan edit (dengan ?id)
$mode_edit = isset($_GET['id']);
$id = $mode_edit ? ambil_id() : null;

$nilai = ['kode' => '', 'nama' => '', 'kategori' => '', 'harga' => '', 'stok' => ''];
$errors = [];

if ($mode_edit) {
    $barang = $id !== null ? ambil_barang($koneksi, $id) : null;

    if ($barang === null) {
        set_flash('danger', 'Data barang tidak ditemukan.');
        redirect('barang.php');
    }

    $nilai = [
        'kode'     => $barang['kode'],
        'nama'     => $barang['nama'],
        'kategori' => $barang['kategori'],
        'harga'    => $barang['harga'],
        'stok'     => $barang['stok'],
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!cek_csrf()) {
        $errors['umum'] = 'Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.';
    } else {
        $nilai = ambil_data_barang();
        $errors = validasi_barang($nilai);

        if (!$errors && kode_sudah_ada($koneksi, $nilai['kode'], $id ?? 0)) {
            $errors['kode'] = 'Kode barang sudah dipakai barang lain.';
        }

        if (!$errors) {
            try {
                if ($mode_edit) {
                    ubah_barang($koneksi, $id, $nilai);
                    set_flash('success', 'Data barang berhasil diperbarui.');
                } else {
                    tambah_barang($koneksi, $nilai);
                    set_flash('success', 'Barang berhasil ditambahkan.');
                }
                redirect('barang.php'); // POST-redirect-GET
            } catch (mysqli_sql_exception $ex) {
                if ($ex->getCode() === 1062) {
                    $errors['kode'] = 'Kode barang sudah dipakai barang lain.';
                } else {
                    $errors['umum'] = 'Data gagal disimpan. Silakan coba lagi.';
                }
            }
        }
    }
}

$judul = $mode_edit ? 'Edit Barang' : 'Tambah Barang';
$action = $mode_edit ? 'barang_form.php?id=' . (int) $id : 'barang_form.php';
require 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-12 col-lg-7">
        <div class="card">
            <div class="card-body p-4">
                <h1 class="h4 mb-3"><?= e($judul) ?></h1>

                <?php if (isset($errors['umum'])): ?>
                    <div class="alert alert-danger"><?= e($errors['umum']) ?></div>
                <?php endif; ?>

                <form method="post" action="<?= e($action) ?>" novalidate>
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label for="kode" class="form-label">Kode barang</label>
                        <input type="text" id="kode" name="kode" maxlength="20"
                               class="form-control<?= kelas_invalid($errors, 'kode') ?>" value="<?= e($nilai['kode']) ?>">
                        <div class="invalid-feedback"><?= e($errors['kode'] ?? '') ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama barang</label>
                        <input type="text" id="nama" name="nama" maxlength="100"
                               class="form-control<?= kelas_invalid($errors, 'nama') ?>" value="<?= e($nilai['nama']) ?>">
                        <div class="invalid-feedback"><?= e($errors['nama'] ?? '') ?></div>
                    </div>

                    <div class="mb-3">
                        <label for="kategori" class="form-label">Kategori</label>
                        <input type="text" id="kategori" name="kategori" maxlength="50"
                               class="form-control<?= kelas_invalid($errors, 'kategori') ?>" value="<?= e($nilai['kategori']) ?>">
                        <div class="invalid-feedback"><?= e($errors['kategori'] ?? '') ?></div>
                    </div>

                    <div class="row">
                        <div class="col-12 col-sm-6 mb-3">
                            <label for="harga" class="form-label">Harga (Rp)</label>
                            <input type="number" id="harga" name="harga" min="0" step="1" inputmode="numeric"
                                   class="form-control<?= kelas_invalid($errors, 'harga') ?>" value="<?= e($nilai['harga']) ?>">
                            <div class="invalid-feedback"><?= e($errors['harga'] ?? '') ?></div>
                        </div>
                        <div class="col-12 col-sm-6 mb-3">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="number" id="stok" name="stok" min="0" step="1" inputmode="numeric"
                                   class="form-control<?= kelas_invalid($errors, 'stok') ?>" value="<?= e($nilai['stok']) ?>">
                            <div class="invalid-feedback"><?= e($errors['stok'] ?? '') ?></div>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="barang.php" class="btn btn-outline-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
