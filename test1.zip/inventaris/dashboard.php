<?php
require_once 'includes/init.php';
wajib_login();

$daftar = ambil_semua_barang($koneksi);
$total = hitung_total($daftar);
$terbaru = array_slice($daftar, 0, 5);

$judul = 'Dashboard';
require 'includes/header.php';
?>

<h1 class="h4 mb-4">Dashboard</h1>

<div class="row g-3 mb-4">
    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-secondary">Jumlah barang</div>
                <div class="angka-ringkasan"><?= number_format($total['jumlah'], 0, ',', '.') ?></div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-secondary">Total stok</div>
                <div class="angka-ringkasan"><?= number_format($total['stok'], 0, ',', '.') ?></div>
            </div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="text-secondary">Total nilai</div>
                <div class="angka-ringkasan"><?= e(rupiah($total['nilai'])) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="h6 mb-0">Barang terbaru</h2>
            <a href="barang_form.php" class="btn btn-sm btn-primary">Tambah barang</a>
        </div>

        <?php if (!$terbaru): ?>
            <p class="mb-0 text-secondary">Belum ada data barang. Mulai dengan menambahkan barang pertama.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr><th>Kode</th><th>Nama</th><th>Kategori</th><th class="kolom-angka">Stok</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($terbaru as $b): ?>
                            <tr>
                                <td><?= e($b['kode']) ?></td>
                                <td><?= e($b['nama']) ?></td>
                                <td><?= e($b['kategori']) ?></td>
                                <td class="kolom-angka"><?= e($b['stok']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
