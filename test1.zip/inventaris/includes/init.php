<?php
// Dipanggil di awal setiap halaman.
date_default_timezone_set('Asia/Jakarta');

require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../fungsi/helper.php';
require_once __DIR__ . '/../fungsi/validasi.php';
require_once __DIR__ . '/../fungsi/user.php';
require_once __DIR__ . '/../fungsi/barang.php';

mulai_session();
