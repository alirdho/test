</main>

<footer class="app-footer">
    <div class="container">
        <small>&copy; <?= date('Y') ?> Inventaris Barang. Latihan PHP Native + MySQL.</small>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>
</body>
</html>
