<?php
// Variabel yang dipakai: $judul (judul halaman)
$judul = $judul ?? 'Halaman';
$flash = ambil_flash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judul) ?> - Inventaris Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">

<header class="app-header">
    <div class="container">
        <span class="app-title">Inventaris Barang</span>
    </div>
</header>

<nav class="navbar navbar-expand-md app-nav" data-bs-theme="dark">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuUtama"
                aria-controls="menuUtama" aria-expanded="false" aria-label="Buka menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menuUtama">
            <?php if (sudah_login()): ?>
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link<?= menu_aktif(['dashboard.php']) ?>" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link<?= menu_aktif(['barang.php', 'barang_form.php']) ?>" href="barang.php">Data Barang</a></li>
                    <li class="nav-item"><a class="nav-link<?= menu_aktif(['laporan.php']) ?>" href="laporan.php">Laporan</a></li>
                </ul>
                <form method="post" action="logout.php" class="d-flex align-items-center gap-3">
                    <?= csrf_field() ?>
                    <span class="navbar-text"><?= e($_SESSION['user_nama']) ?></span>
                    <button type="submit" class="btn btn-sm btn-outline-light">Logout</button>
                </form>
            <?php else: ?>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link<?= menu_aktif(['login.php']) ?>" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link<?= menu_aktif(['registrasi.php']) ?>" href="registrasi.php">Registrasi</a></li>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</nav>

<main class="container py-4 flex-grow-1">
    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['tipe']) ?>" role="alert"><?= e($flash['pesan']) ?></div>
    <?php endif; ?>
